package com.Pronto.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.Pronto.operation.UIOperationMethods;

public class FinalValidationReadWrite {
	
	static Cell cell;
	static WebDriver driver;
	static String ObjectName;
	static String ObjectType;
	String InputData;
	static String ObjectNameValue;
	static Sheet sheet1;
	static String result;
	HSSFWorkbook workbook ;

	public static void main(String args[]) throws Exception {		
		FinalValidationReadWrite vr=new FinalValidationReadWrite();
		vr.readData();				
	}
	

	
	
	public static void readData() throws IOException {

		try {
			FileInputStream fis = new FileInputStream("D:\\Neelam_Automation_Work\\project\\ProntoRx-Automation\\PRONTORX\\InputData\\TestSuite\\ProntoRX.xls");
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			HSSFSheet worksheet = workbook.getSheetAt(3);
			System.out.println("Name Of Worksheet=====" + worksheet.getSheetName());
			int rows = worksheet.getLastRowNum();
			for (int i = 0; i < rows + 1; i++) {
				String data1 = worksheet.getRow(i).getCell(0).getStringCellValue();
				System.out.println("Data from First column and from row " + i + " is " + data1);
				// System.out.println("Data from Second column and from row "+i+" is "+data2);
				System.out.println("===========================================");
				if (data1.equalsIgnoreCase("VERIFY_TEXT")) {
					System.out.println("Data OF First COLUMN OF VERIFY_TEXT================== " + i + " is " + data1);
					ObjectNameValue = worksheet.getRow(i).getCell(1).getStringCellValue();
					System.out.println("ObjectNameValue value=====================" + ObjectNameValue);
					String ObjectTypeValue = worksheet.getRow(i).getCell(2).getStringCellValue();
					System.out.println("ObjectTypeValue value=====================" + ObjectTypeValue);
					String InputData = worksheet.getRow(i).getCell(3).getStringCellValue();
					System.out.println("Input data value=====================" + InputData);
					System.out.println("Value of XPATH of ObjectType============" +UIOperationMethods.strElementText);
					if (UIOperationMethods.strElementText.equalsIgnoreCase(InputData)) {
						System.out.println("Pass");
						result = "PASS";
					} else {
						System.out.println("FAIL");
						result = "FAIL";
					}
					try {
						FileInputStream file = new FileInputStream(
								new File("C:\\project\\3-7-2020\\PRONTORX\\PrescriberValidation.xls"));
						workbook = new HSSFWorkbook(file);
						HSSFSheet sheet = workbook.getSheetAt(0);
						System.out.println("sheet==================="+sheet.getSheetName());
						Cell cell = null;
						// NPI Field
						int row1 = sheet.getLastRowNum();
						for (int j = 0; j < row1 + 1; j++) {

							String ObjectNameOfResultFile = sheet.getRow(j).getCell(1).getStringCellValue();
							System.out.println("ObjectNameOfResultFile=======" + ObjectNameOfResultFile);
						
							
							//String InputDataOfResultFile = sheet.getRow(j).getCell(4).getStringCellValue();
						//	System.out.println("InputDataOfResultFile=======" + InputDataOfResultFile);
						
							
							if (ObjectNameOfResultFile.equals(ObjectNameValue)) {
								sheet.getRow(j).getCell(5).setCellValue(result);
								
								

							}
						//	if(InputDataOfResultFile.contains(InputData)) {
						//		sheet.getRow(j).getCell(5).setCellValue("PASS");
						//	}
				
							file.close();
							FileOutputStream outFile = new FileOutputStream(
									new File("D:\\Neelam_Automation_Work\\project\\ProntoRx-Automation\\PRONTORX\\\\InputData\\\\TestSuite\\PrescriberValidation.xls"));
							workbook.write(outFile);
							outFile.close();
						}
					} catch (FileNotFoundException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
		

			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} 
	}
	public static void enterTextVerification() {
		try {
			
			
			
		}catch (Exception e) {
			
		}
	}
}



	


