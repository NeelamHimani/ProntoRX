package com.Pronto.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.annotations.DataProvider;

import com.Pronto.operation.UIOperationMethods;
import com.microsoft.schemas.office.visio.x2012.main.CellType;

public class ValidationExcelReader {
	
	
	
	
	public static HSSFWorkbook excelWorkbook = null;
	public static HSSFSheet excelSheet = null;
	public static HSSFRow row = null;
	public static HSSFCell cell = null;
	public static String ValidationErrorMessage;
	public static String result;
	
	
	public static void main(String args[]) throws IOException {
	
	
	}
	public static void readDataFromExcel() throws IOException {
		getfile("C:\\project\\3-7-2020\\PRONTORX\\InputData\\TestSuite\\ProntoRX.xls");		
		System.out.println("Object Name====="+getExcelData(3, 12, 1));
		String InputData=getExcelData(3,12,3);
		System.out.println("Input data==============="+InputData);
		getfile("C:\\project\\3-7-2020\\PRONTORX\\PrescriberValidation.xls");
		String objectNameOfResul=getExcelData(0,1, 1);
		System.out.println("Object Name Of Result File==============="+objectNameOfResul);
		ValidationErrorMessage=UIOperationMethods.strElementText;
		System.out.println("validation error message ======"+ValidationErrorMessage);
		if(UIOperationMethods.strElementText.equalsIgnoreCase(InputData)) {
			result="PASS";
			System.out.println(result);
			
			setResultValue(0,1,5);
		}
		else {
			result="FAIL";
			System.out.println(result);
			setResultValue(0,1,5);
		}
		setData(0, 1, 6);
		
		
	}
	
	public static String getfile(String filePath) throws IOException {
		
		FileInputStream fis = new FileInputStream(filePath); // Your .xlsx file name along with path
		excelWorkbook = new HSSFWorkbook(fis);
		return filePath;
	}
	public static String getExcelData(int index,int row,int col) throws IOException
	{
		excelSheet = excelWorkbook.getSheetAt(index);
		System.out.println("sheet==================="+excelSheet.getSheetName());
		// Read sheet inside the workbook by its name
		//excelSheet = excelWorkbook.getSheet("Validation"); //Your sheet name
		Cell data=excelSheet.getRow(row).getCell(col);
		System.out.println("data==="+data.getStringCellValue());
		return data.getStringCellValue();
		
	}
	public static String setData(int index1,int row1,int col1) throws IOException {
		 
		System.out.println("=======setData=====");
		excelSheet = excelWorkbook.getSheetAt(index1);
		System.out.println("sheet==================="+excelSheet.getSheetName());
		// Read sheet inside the workbook by its name
		//excelSheet = excelWorkbook.getSheet("Validation"); //Your sheet name
		Cell data=excelSheet.getRow(row1).getCell(col1);
		data.setCellValue(ValidationErrorMessage);

		FileOutputStream outFile = new FileOutputStream(
				new File("C:\\project\\3-7-2020\\PRONTORX\\PrescriberValidation.xls"));
		excelWorkbook.write(outFile);
		outFile.close();
		
		return data.getStringCellValue();
	
	}
	public static String setResultValue(int index1,int row1,int col1) throws IOException {
		 
		System.out.println("=======setResultData=====");
		excelSheet = excelWorkbook.getSheetAt(index1);
		System.out.println("sheet==================="+excelSheet.getSheetName());
		// Read sheet inside the workbook by its name
		//excelSheet = excelWorkbook.getSheet("Validation"); //Your sheet name
		Cell data=excelSheet.getRow(row1).getCell(col1);
		data.setCellValue(result);

		FileOutputStream outFile = new FileOutputStream(
				new File("C:\\project\\3-7-2020\\PRONTORX\\PrescriberValidation.xls"));
		excelWorkbook.write(outFile);
		outFile.close();
		
		return data.getStringCellValue();
	
	}
	
}