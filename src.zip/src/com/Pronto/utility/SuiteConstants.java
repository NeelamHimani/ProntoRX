package com.Pronto.utility;

public class SuiteConstants {
	
	public static final String KEYWORD_COLUMN = "Keyword";
	public static final String OBJECT_NAME_COLUMN = "ObjectName";
	public static final String OBJECT_TYPE_COLUMN = "ObjectType";
	public static final String INPUTDATA_COLUMN = "InputData";
	public static final String PURPOSE_COLUMN = "Purpose";
	public static final String SCREENSHOT_COLUMN = "ScreenShot";
	public static final String RESULT_COLUMN = "Result";
	public static final int Col_Result =3 ;
	public static final int Col_TestStepResult =5 ;


	public static final String KEYWORD_FAIL = "FAIL";
	public static final String KEYWORD_PASS = "PASS";
	
	public static final String FIREFOX_BROWSER = "FIREFOX";
	public static final String CHROME_BROWSER = "CHROME";
	public static final String IE_BROWSER = "IE";
	public static final String CHROME_REMOTE_DRIVER_HOST = "127.0.0.1";
	

}
