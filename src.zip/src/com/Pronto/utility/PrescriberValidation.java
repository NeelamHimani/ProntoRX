package com.Pronto.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Iterator;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class PrescriberValidation {
	
	static Cell cell;
	static WebDriver driver;
	static String ObjectName;
	static String ObjectType;
	String InputData;
	static String ObjectNameValue;
	static Sheet sheet1;
	static String result;
	HSSFWorkbook workbook ;
	
	public static void main(String args[]) {
		readValidationData();
		
	}

	public static void readValidationData() {
		try {
			FileInputStream fis = new FileInputStream("C:\\project\\PRONTORX\\InputData\\TestSuite\\ProntoRX.xls");
			HSSFWorkbook workbook = new HSSFWorkbook(fis);
			HSSFSheet worksheet = workbook.getSheetAt(3);
			System.out.println("Name Of Worksheet=====" + worksheet.getSheetName());
			if(worksheet.getSheetName().equalsIgnoreCase("Validation")) {
				int rows = worksheet.getLastRowNum();
				for (int i = 0; i < rows + 1; i++) {
					String data1 = worksheet.getRow(i).getCell(1).getStringCellValue();
					System.out.println(""+ i + " " + data1);
					if(data1.equalsIgnoreCase("ProntoRX_Register_Next_Button")) {
						System.out.println("========Validation Scenario for NEXT Button================ ");
						
					}
				}
			}
			
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
