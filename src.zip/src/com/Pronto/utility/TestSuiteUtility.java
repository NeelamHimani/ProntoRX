package com.Pronto.utility;

import java.util.ArrayList;
import java.util.List;

import com.Pronto.pojo.TestData;

import java.io.FileInputStream;
import java.io.FileOutputStream;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestSuiteUtility {
	
	  private static XSSFSheet ExcelWSheet;
      private static XSSFWorkbook ExcelWBook;
      private static XSSFCell Cell;
      private static XSSFRow Row;
      
	public static Object[][] getTestDataUtility(ExcelReader xls, String sheetName) {
		return xls.retrieveTestCaseData(sheetName);
	}

	public static List<TestData> getTestData(ExcelReader filePath, String testCaseSheetName) {
		
		final List<TestData> testDataList = new ArrayList<>();

		final Object[][] rawTestData = TestSuiteUtility.getTestDataUtility(filePath, testCaseSheetName);

		for (int i = 0; i < rawTestData.length; i++) {
			TestData testData = new TestData();

			testData.setKeyword((String) rawTestData[i][filePath.getColumnNumber(testCaseSheetName,
					SuiteConstants.KEYWORD_COLUMN)]);
			testData.setObjectName((String) rawTestData[i][filePath.getColumnNumber(testCaseSheetName,
					SuiteConstants.OBJECT_NAME_COLUMN)]);
			testData.setObjectType((String) rawTestData[i][filePath.getColumnNumber(testCaseSheetName,
					SuiteConstants.OBJECT_TYPE_COLUMN)]);
			testData.setInputData((String) rawTestData[i][filePath.getColumnNumber(testCaseSheetName,
					SuiteConstants.INPUTDATA_COLUMN)]);
			testData.setPurpose((String) rawTestData[i][filePath.getColumnNumber(testCaseSheetName,
					SuiteConstants.PURPOSE_COLUMN)]);
			testData.setTakeScreenShot((String) rawTestData[i][filePath.getColumnNumber(testCaseSheetName,
					SuiteConstants.SCREENSHOT_COLUMN)]);
			testData.setResult((String) rawTestData[i][filePath.getColumnNumber(testCaseSheetName,
					SuiteConstants.RESULT_COLUMN)]);
			testDataList.add(testData);

		}
		return testDataList;
	}
	
	//This method is use to write value in the excel sheet
	//This method accepts four arguments (Result, Row Number, Column Number & Sheet Name)
	public static void setCellData(String Result, int RowNum, int ColNum, String SheetName) throws Exception {
		try {

			ExcelWSheet = ExcelWBook.getSheet(SheetName);
			Row = ExcelWSheet.getRow(RowNum);
			Cell = Row.getCell(ColNum, Row.RETURN_BLANK_AS_NULL);
			if (Cell == null) {
				Cell = Row.createCell(ColNum);
				Cell.setCellValue(Result);
			} else {
				Cell.setCellValue(Result);
			}
			// Constant variables Test Data path and Test Data file name
			FileOutputStream fileOut = new FileOutputStream(
					"C:\\project\\PRONTORX\\InputData\\TestSuite\\ProntoRX.xls");
			ExcelWBook.write(fileOut);
			// fileOut.flush();
			fileOut.close();
			ExcelWBook = new XSSFWorkbook(
					new FileInputStream("C:\\project\\PRONTORX\\InputData\\TestSuite\\ProntoRX.xls"));
		} catch (Exception e) {
			// Driver.bResult = false;
		}
	}
}
